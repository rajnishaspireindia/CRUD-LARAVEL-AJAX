@extends('layout')

@section('title', 'Students List')

@section('content')
<section class="p-3" style="min-height:calc(100vh - 112px)">
    <div class="message"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title m-0 float-left">Students List</h3>
                        <a href="students/create" class="btn btn-success float-right">Add New</a>
                    </div>
                    <div class="card-body">
                    @if(Session::has('status'))
                        <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('status') }}</p>
                    @endif
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Gender</th>
                                    <th>Image</th>
                                    <th>Address</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            	<?php  $k=1; ?>
                            	@foreach($details as $detail)
                                <tr>
                                	<td>{{$k}}</td>
                                	<td>{{$detail['fname']}}</td>
                                	<td>{{$detail['lname']}}</td>
                                	<td>{{$detail['email']}}</td>
                                	<td>{{$detail['phone']}}</td>
                                	<td>@if($detail['gender']=='m')
                                	        {{'Male'}}
                                	     @else
                                	         {{'Female'}}
                                	    @endif</td>
                                	<td><img src="{{asset('assets/uploads')}}/{{$detail['image']}}" width="75px"></td>
                                	<td>{{$detail['address']}}</td>
                                    <td><a class="btn btn-primary edit-btn" href="{{url('students/'.$detail['id'].'/edit')}}">Edit</a> &nbsp;&nbsp;<a href="javascript:void(0)" class="delete-student btn btn-danger" data-id="{{$detail['id']}}">Delete</a></td>

                                </tr>
                                <?php $k++;?>
                                @endforeach
                            </tbody>
                            
                        </table>
                        <div class="card-footer">
                        {{ $details->links('pagination::bootstrap-4'); }}
                    </div>
                    </div>
                    <div class="card-footer">
                         
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection