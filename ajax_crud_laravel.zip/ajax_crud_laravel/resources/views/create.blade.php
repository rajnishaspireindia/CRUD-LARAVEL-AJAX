@extends('layout')

@section('title', 'Add New Student')

@section('content')
<section class="p-3" style="min-height:calc(100vh - 112px)">
    <div class="message"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                  <div class="card-header">
                    <h3 class="card-title m-0 float-left">Add New Student</h3>
                    <a href="/students" class="btn btn-success float-right">All Students</a>
                   </div>
                   <div class="card-body">
                   <input type="hidden" class="url" value="{{url('/students')}}" >
                   <form id="add_student" class="form-horizontal" method="POST" enctype="multipart/form-data">
                            @csrf
                            <div class="form-group row">
                                <label for="name" class="col-sm-3 text-right"><b>Name:</b></label>
                                <div class="col-sm-3">
                                    <input type="text" class="form-control" name="fname" placeholder="First Name">
                                </div>
                                <div class="col-sm-3">
                                    <input type="text" class="form-control" name="lname" placeholder="Last Name">
                                </div>
                            </div>
                            <div class="form-group row">
                            	<label for="email" class="col-sm-3 text-right"><b>Email:</b></label>
                            	<div class="col-sm-6">
                            		<input type="email" class="form-control" name="email" placeholder="Enter Email Id" required>
                            	</div>
                            </div>
                            <div class="form-group row">
                            	<label for="phone" class="col-sm-3 text-right"><b>Phone:</b></label>
                            	<div class="col-sm-6">
                            		<input type="text" class="form-control" name="phone" placeholder="Enter Phone Number" required>
                            	</div>
                            </div>
                            <div class="form-group row">
                                <label for="gender" class="col-sm-3 text-right"><b>Gender:</b></label>
                                <div class="col-sm-3">
                                    <input type="radio" name="gender" value="m" checked=""> Male
                                    <input type="radio" name="gender" value="f"> Female
                                </div>
                            </div>
                            <div class="form-group row">
                            	<label for="image" class="col-sm-3 text-right"><b>Image:</b></label>
                            	<div class="col-sm-6">
                            		<input type="file" class="form-control" name="image" required>
                            	</div>
                            </div>
                            <div class="form-grou row">
                            	<label for="address" class="col-sm-3 text-right"><b>Address:</b></label>
                            	<div class="col-sm-6">
                            		<textarea class="form-control" name="address" placeholder="Enter Address..."></textarea>
                            	</div>
                            </div>
                            <div class="form-group row pt-2">
                                <div class="col-sm-12 text-center">
                                    <input type="submit" class="btn btn-success" value="Submit">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection