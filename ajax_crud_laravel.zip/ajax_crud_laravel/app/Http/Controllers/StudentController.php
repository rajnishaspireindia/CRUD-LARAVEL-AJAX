<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Illuminate\Http\Request;

class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       $student['details']=Student::OrderBy('id','DESC')->paginate(5);
       return view('index',$student);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
      return view('create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
         
             'fname'=>'required',
             'email'=>'required|email|unique:students,email',
             'phone'=>'required',
             'address'=>'required',
             'gender'=>'required',
             'image'=>'required'
        ]);

        $student=new Student;
        if($request->hasFile('image'))
        {
        $image=$request->file('image');
        $input['imagename']=time().'.'.$image->getClientOriginalExtension();
        $destinationPath=public_path('/assets/uploads');
        $image->move($destinationPath,$input['imagename']); 
        $student->fname=$request->post('fname');
        $student->lname=$request->post('lname');
        $student->email=$request->post('email');
        $student->phone=$request->post('phone');
        $student->gender=$request->post('gender');
        $student->image=$input['imagename'];
        $student->address=$request->post('address');
        $student->save();
        return 1;
        }
        
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function show(Student $student)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {
        $details['students']=Student::find($id);
        return view('edit',$details);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
         $student=Student::find($id);
         if($request->hasFile('image'))
         {
            $image=$request->file('image');
            $input['imagename']=time().'.'.getClientOriginalExtension();
            $destinationPath=public_path('/assets/uploads');
            $image->move($destinationPath,$input['imagename']);
            $student->fname=$request->post('fname');
            $student->lname=$request->post('lname');
            $student->email=$request->post('email');
            $student->phone=$request->post('phone');
            $student->gender=$request->post('gender');
            $student->image=$input['imagename'];
            $student->address=$request->post('address');
            $student->update();
            return 1; 
         }
         else

         {
            $student->fname=$request->post('fname');
            $student->lname=$request->post('lname');
            $student->email=$request->post('email');
            $student->phone=$request->post('phone');
            $student->gender=$request->post('gender');
            $student->address=$request->post('address');
            $student->update();
            return 1; 
         }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$id)
    {
      $destroy = Student::where('id',$id)->delete();
        return $destroy;
    }
}
