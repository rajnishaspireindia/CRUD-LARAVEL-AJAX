

<?php $__env->startSection('title', 'Students List'); ?>

<?php $__env->startSection('content'); ?>
<section class="p-3" style="min-height:calc(100vh - 112px)">
    <div class="message"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title m-0 float-left">Students List</h3>
                        <a href="students/create" class="btn btn-success float-right">Add New</a>
                    </div>
                    <div class="card-body">
                    <?php if(Session::has('status')): ?>
                        <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('status')); ?></p>
                    <?php endif; ?>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Gender</th>
                                    <th>Image</th>
                                    <th>Address</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            	<?php  $k=1; ?>
                            	<?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                	<td><?php echo e($k); ?></td>
                                	<td><?php echo e($detail['fname']); ?></td>
                                	<td><?php echo e($detail['lname']); ?></td>
                                	<td><?php echo e($detail['email']); ?></td>
                                	<td><?php echo e($detail['phone']); ?></td>
                                	<td><?php if($detail['gender']=='m'): ?>
                                	        <?php echo e('Male'); ?>

                                	     <?php else: ?>
                                	         <?php echo e('Female'); ?>

                                	    <?php endif; ?></td>
                                	<td><img src="<?php echo e(asset('assets/uploads')); ?>/<?php echo e($detail['image']); ?>" width="75px"></td>
                                	<td><?php echo e($detail['address']); ?></td>
                                    <td><a class="btn btn-primary edit-btn" href="<?php echo e(url('students/'.$detail['id'].'/edit')); ?>">Edit</a> &nbsp;&nbsp;<a href="javascript:void(0)" class="delete-student btn btn-danger" data-id="<?php echo e($detail['id']); ?>">Delete</a></td>

                                </tr>
                                <?php $k++;?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            
                        </table>
                        <div class="card-footer">
                        <?php echo e($details->links('pagination::bootstrap-4')); ?>

                    </div>
                    </div>
                    <div class="card-footer">
                         
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ajax_crud_laravel\resources\views/index.blade.php ENDPATH**/ ?>